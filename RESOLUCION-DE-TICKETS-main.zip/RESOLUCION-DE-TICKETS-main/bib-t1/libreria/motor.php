<?php
include ("config.php");
include ("conexion.php");
//include ("estudiante.php");
//include ("libro_d.php");
$objConexion = new Conexion();
?>